import java.io.IOException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Attributes;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.w3c.dom.Attr;


public class Parse {

     public static void main(String args[]){
          System.out.println("running...");

          ArrayList<Document> recDoc = new ArrayList<>();
          ArrayList<Document> revDoc = new ArrayList<>();
          ArrayList<String> ratings = new ArrayList<>();

          Document catDoc;


          try {

              //Get Document object after parsing the html from given url.
              catDoc = Jsoup.connect("https://www.allrecipes.com/recipes/233/world-cuisine/asian/indian/?page=2").get(); //Connects to category "Indian" page 1

              String title = catDoc.title(); //Get title of link
              System.out.println("  Title: " + title); //Print title

              Elements recipesURL = catDoc.select(".fixed-recipe-card__title-link[href]"); //Extracts class containing a link in each recipe box


              for (int i=0; i < recipesURL.size(); i++) {

                  System.out.println("URL" + (i+1) + ": " + recipesURL.get(i).text()); //Prints title of link in a recipe's class
                  System.out.println(recipesURL.get(i).attr("abs:href")); //Prints link to recipe
                  recDoc.add(Jsoup.connect(recipesURL.get(i).attr("abs:href")).get()); //Connects to a recipe link

                  Recipe newRecipe = new Recipe(recipesURL.get(i).text()); //Names new recipe by recipe name

                  newRecipe.setLink(recipesURL.get(i).attr("abs:href")); //Link to recipe
                  newRecipe.setSubmitter(recDoc.get(i).select(".submitter__name").text()); //Recipe submitter
                  newRecipe.setDescription(recDoc.get(i).select(".submitter__description").text()); //Recipe description

                  Elements direction = recDoc.get(i).select(".recipe-directions__list li.step span.recipe-directions__list--item"); //Recipe directions

                  for (int j=0; j < direction.size()-1; j++) {
                      newRecipe.directions.add(direction.get(j).text()); //Stores recipe directions in order
                  }

                  Elements reviewsURL = recDoc.get(i).select(".review-container.clearfix div.review-detail a.review-detail__link[href]"); //Extracts full review links

                  revDoc.add(Jsoup.connect(reviewsURL.get(i).attr("abs:href")).get()); //Connects to review link
                  Elements reviewz = revDoc.get(i).select(".review-container div.review-detail.clearfix p"); //Extracts text in full review
                  System.out.println(reviewz.get(0).ownText());

                  Elements rating = recDoc.get(i).select(".recipe-summary.clearfix div.recipe-summary__stars span.aggregate-rating meta[itemprop=ratingValue]"); //Extracts class containing recipe rating
                  System.out.println("Rating: " + rating.get(0).attr("content")); //Prints rating


                  System.out.println();
                  TimeUnit.MILLISECONDS.sleep(1000);
              }

          } catch(IOException | InterruptedException e) {
              e.printStackTrace();
          }
          System.out.println("done");
     }

}
