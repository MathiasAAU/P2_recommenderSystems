import java.util.ArrayList;

public class Recipe {

    private String name;
    private String submitter;
    private String category;
    private String link;
    private String description;
    private double rating;
    ArrayList<String> directions = new ArrayList<>();
    ArrayList<String> reviews = new ArrayList<>();

    public Recipe(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String getSubmitter() {
        return submitter;
    }

    public void setSubmitter(String submitter) {
        this.submitter = submitter;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

}
