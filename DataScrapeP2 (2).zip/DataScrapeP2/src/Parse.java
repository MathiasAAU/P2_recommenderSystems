import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;


public class Parse {

    public static void main(String args[]){
          System.out.println("running...");

          Document[] documents = new Document[500];
          Document document;
          Document document2;

          try {

            //Get Document object after parsing the html from given url.
            document = Jsoup.connect("https://www.allrecipes.com/recipes/233/world-cuisine/asian/indian/?page=1").get(); //Connects to category "Indian" page 1

            String title = document.title(); //Get title of link
            System.out.println("  Title: " + title); //Print title

            Elements URL = document.select(".fixed-recipe-card__title-link[href]"); //Extracts class containing a link in each recipe box

            for (int i=0; i < URL.size(); i++) {
                System.out.println("URL" + (i+1) + ": " + URL.get(i).text()); //Prints title of link in a recipe's class
                System.out.println(URL.get(i).attr("abs:href")); //Prints link to recipe
            }

      } catch(IOException e) {
            e.printStackTrace();
      }
        System.out.println("done");
    }

  }
