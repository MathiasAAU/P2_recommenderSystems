package userclasses;
import recipeclasses.Review;
import java.util.List;
import java.util.Objects;

public class User {
    private String ID;
    private String userName;
    private List<Review> reviews;

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public List<Review> getReviews() {
        return reviews;
    }

    void addReview(Review R){
        reviews.add(R);
    }

    void removeReview(Review R){
        reviews.remove(R);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return Objects.equals(ID, user.ID);
    }

    @Override
    public int hashCode() {

        return Objects.hash(ID);
    }
}
