package com.example.trying_out;

import android.graphics.Color;
import android.os.DropBoxManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.github.mikephil.charting.listener.OnChartGestureListener;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

   private static final String TAG = "MainActivity";

   private LineChart mChart;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Weight control");
        // ImageView imageView = (ImageView) findViewById(R.id.imageView2);

        mChart = (LineChart) findViewById(R.id.lineChart);

    //    mChart.setOnChartGestureListener(MainActivity.this);
    //    mChart.setOnChartValueSelectedListener(MainActivity.this);

        mChart.getDescription().setEnabled(false);
        mChart.setDragEnabled(true);
        mChart.setScaleEnabled(false);

        ArrayList<Entry> userWeight = new ArrayList<>();

        userWeight.add(new Entry(1,9));
        userWeight.add(new Entry(2,8));
        userWeight.add(new Entry(3,7));
        userWeight.add(new Entry(4,6));

        ArrayList<Entry> goalWeight = new ArrayList<>();

        goalWeight.add(new Entry(1,9));
        goalWeight.add(new Entry(2,8));
        goalWeight.add(new Entry(6,7));
        goalWeight.add(new Entry(10,6));

        LineDataSet set1 = new LineDataSet(userWeight,"Your weight");
        LineDataSet set2 = new LineDataSet(goalWeight,"Goal weight");
        set1.setFillAlpha(110);
        set2.setFillAlpha(110);

        ArrayList<ILineDataSet> dataSets = new ArrayList<>();

        set1.setColor(Color.RED);
        set1.setCircleColor(Color.RED);
        dataSets.add(set1);

        dataSets.add(set2);

        LineData data = new LineData(dataSets);

        mChart.setData(data);

    }
}

