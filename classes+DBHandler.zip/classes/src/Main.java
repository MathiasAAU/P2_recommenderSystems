import database.DBHandler;
import recipeclasses.CookTime;
import recipeclasses.Recipe;

import java.util.List;

public class Main {
    public static void main(String[] args) {

        Recipe recipe = new Recipe();
        CookTime cookTime = new CookTime();
        DBHandler.createCon();
        DBHandler.exeQuery(185, recipe);
        DBHandler.exeQuery2(185, cookTime);
        DBHandler.exeQuery3(185, recipe);




        String title = recipe.getTitle();
        String cookingTime = cookTime.getCookTime();
        List<String> categories = recipe.getCategories();

        System.out.println(title);
        System.out.println(cookingTime);
        System.out.println(categories);


        DBHandler.closeCon();
    }
}
