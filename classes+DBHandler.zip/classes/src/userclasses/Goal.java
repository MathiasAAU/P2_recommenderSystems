package userclasses;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Goal {
    public static Map<Date, Double> userWeight = new HashMap<>();
    public static Map<Date, Double> goalWeight = new HashMap<>();

    public void addUserWeight(Date date, double weight){
        userWeight.put(date, weight);
    }

    public void addGoalWeight(Date date, double weight){
        goalWeight.put(date, weight);
    }
}
