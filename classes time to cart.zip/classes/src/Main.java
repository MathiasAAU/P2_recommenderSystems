import database.DBHandler;
import recipeclasses.Recipe;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        DBHandler.createCon();
        List<Integer> IDs = new ArrayList<>();
        for(int i = 0; i < 20; i++){
            IDs.add(3000 + i);
        }

        LocalTime time = LocalTime.now();
        DBHandler.getRecipesFromList(IDs);
        LocalTime time1 = LocalTime.now();

        System.out.println(time);
        System.out.println(time1);



        DBHandler.closeCon();
    }
}
