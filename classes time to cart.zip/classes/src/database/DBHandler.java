package database;

import recipeclasses.CookTime;
import recipeclasses.Ingredients;
import recipeclasses.Recipe;
import recipeclasses.Review;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DBHandler {

    // JDBC driver name and database URL
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://35.198.191.151:3306/p2?useSSL=false";

    //  Database credentials
    static final String USER = "root";
    static final String PASS = "admin";

    static Connection conn = null;
    static Statement stmt = null;
    static ResultSet rs = null;

    static public void createCon() {

        //Register JDBC driver
        System.out.println("Registering JDBC drivers");
        try {
            Class.forName(JDBC_DRIVER);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        //Open a connection
        System.out.println("Connecting to database...");
        try {
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }


    static public List<Recipe> getRecipesFromList(List<Integer> IDs) {
        List<Recipe> recipeList = new ArrayList<>();

        try {
            stmt = conn.createStatement();
            for (int i = 0; i < IDs.size(); i++) {
                Recipe recipe = new Recipe();
                int ID = IDs.get(i);
                String sql = "SELECT title, submitter, picture_link, link, description, servings, calories, rating FROM recipe WHERE recipe_id=" + ID;
                rs = stmt.executeQuery(sql);

                //Extract data from result set
                if (rs.next()) {
                    //Retrieve by column name
                    recipe.setID(ID);
                    recipe.setTitle(rs.getString("title"));
                    recipe.setSubmitterName(rs.getString("submitter"));
                    recipe.setPictureLink(rs.getString("picture_link"));
                    recipe.setWebsiteLink(rs.getString("link"));
                    recipe.setDescription(rs.getString("description"));
                    recipe.setServings(rs.getInt("servings"));
                    recipe.setCalories(rs.getInt("calories"));
                    recipe.setRating(rs.getInt("rating"));
                    recipeList.add(recipe);
                }

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        for (Recipe r : recipeList){
            r.setTime(getTime(r.getID()));
        }

        for (Recipe r : recipeList){
            r.setCategories(getCat(r.getID()));
        }

        for (Recipe r : recipeList){
            r.setIngredients(getIngr(r.getID()));
        }

        return recipeList;
    }


    //Gets information to the recipe class from the database
    static public Recipe getRecipe(int ID) {
        Recipe recipe = new Recipe();
        String title = null;
        String submitterName = null;
        String pictureLink = null;
        String websiteLink = null;
        String description = null;
        int servings = 0;
        int calories = 0;
        double rating = 0;
        CookTime time = null;
        List<String> categories = new ArrayList<>();
        List<Ingredients> ingredients = new ArrayList<>();
        List<String> directions = new ArrayList<>();
        List<Review> reviews = new ArrayList<>();

        try {
            stmt = conn.createStatement();
            String sql = "SELECT title, submitter, picture_link, link, description, servings, calories, rating FROM recipe WHERE recipe_id=" + ID;
            rs = stmt.executeQuery(sql);

            //Extract data from result set
            if (rs.next()) {
                //Retrieve by column name
                title = rs.getString("title");
                submitterName = rs.getString("submitter");
                pictureLink = rs.getString("picture_link");
                websiteLink = rs.getString("link");
                description = rs.getString("description");
                servings = rs.getInt("servings");
                calories = rs.getInt("calories");
                rating = rs.getInt("rating");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        time = getTime(ID);
        categories = getCat(ID);
        ingredients = getIngr(ID);


        return new Recipe(ID, title, submitterName, pictureLink, websiteLink, description, servings, calories, rating, time, categories, ingredients, directions, reviews);
    }

    //Gets information to the cooktime class from the database
    static public CookTime getTime(int ID) {
        String prepTime = null;
        String cookTime = null;
        String readyIn = null;

        try {
            stmt = conn.createStatement();
            String sql = "SELECT prep_time, cook_time, ready_in FROM time WHERE recipe_id=" + ID;
            rs = stmt.executeQuery(sql);

            //Extract data from result set
            if (rs.next()) {
                //Retrieve by column name
                prepTime = rs.getString("prep_time");
                cookTime = rs.getString("cook_time");
                readyIn = rs.getString("ready_in");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return new CookTime(prepTime, cookTime, readyIn);
    }

    //Gets information to the recipe class from the database
    public static List<String> getCat(int ID) {
        List<String> listOfCategoryNames = new ArrayList<>();

        try {
            stmt = conn.createStatement();
            String sql = "SELECT category_name FROM categories WHERE recipe_id=" + ID;
            rs = stmt.executeQuery(sql);


            //Extract data from result set
            while (rs.next()) {
                //Retrieve by column name
                String categoryName = rs.getString("category_name");

                //Adds all the elements to a new list - that later can be initialized in Recipe class
                listOfCategoryNames.add(categoryName);
            }

            //Initialize the field categories in Recipe class

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return listOfCategoryNames;
    }

    //Gets information to the recipe class from the database
    public static List<Ingredients> getIngr(int ID) {
        String ingr_name = null;
        double amount = 0;
        String unit = null;
        String other_unit = null;

        List<Ingredients> ingredientsList = new ArrayList<>();

        try {
            stmt = conn.createStatement();
            String sql = "SELECT amount, unit, other_unit, ingr_name FROM ingredients_formatted WHERE recipe_id=" + ID;
            rs = stmt.executeQuery(sql);

            //Extract data from result set
            while (rs.next()) {
                //Retrieve by column name
                amount = rs.getDouble("amount");
                unit = rs.getString("unit");
                other_unit = rs.getString("other_unit");
                ingr_name = rs.getString("ingr_name");

                ingredientsList.add(new Ingredients(ID, ingr_name, amount, unit, other_unit));
            }


        } catch (SQLException e) {
            e.printStackTrace();
        }

        return ingredientsList;
    }

    //Gets information to the recipe class from the database
    public static List<String> getDir(int ID) {
        System.out.println("Running getDir");
        List<String> listOfDirections = new ArrayList<>();

        try {
            stmt = conn.createStatement();
            String sql = "SELECT directions FROM directions WHERE recipe_id=" + ID;
            rs = stmt.executeQuery(sql);

            //Extract data from result set
            while (rs.next()) {
                //Retrieve by column name
                String recipeDir = rs.getString("directions");
                //Adds all the elements to a new list - that later can be initialized in Recipe class
                listOfDirections.add(recipeDir);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return listOfDirections;
    }

    public static List<Review> getRev(int ID) {
        String reviewText;
        String submitterName;
        String submitterID;
        int individualRating;
        List<Review> reviewList = new ArrayList<>();

        try {
            stmt = conn.createStatement();
            String sql = "SELECT review, submitter, submitter_id, individual_rating FROM reviews WHERE recipe_id=" + ID;
            rs = stmt.executeQuery(sql);

            //5: Extract data from result set
            while (rs.next()) {
                //Retrieve by column name
                reviewText = rs.getString("review");
                submitterName = rs.getString("submitter");
                submitterID = rs.getString("submitter_id");
                individualRating = rs.getInt("individual_rating");

                //Initializing fields in the Review class
                reviewList.add(new Review(ID, reviewText, submitterName, submitterID, individualRating));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return reviewList;
    }

    public static void closeCon() {
        // what exception to use here
        try {
            rs.close();
            if (stmt != null)
                stmt.close();
            if (conn != null)
                conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
