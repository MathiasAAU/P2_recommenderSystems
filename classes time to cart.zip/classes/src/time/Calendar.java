package time;

import java.util.*;

public class Calendar {
    private Date today;
    private Map<Date,Day> dates = new HashMap<>();

    public Date getToday() {
        return today;
    }

    public void setToday(Date today) {
        this.today = today;
    }

    public Map<Date, Day> getDates() {
        return dates;
    }

    public void setDates(Map<Date, Day> dates) {
        this.dates = dates;
    }

    public List<Day> get7DayList() {
        List<Day> res = new ArrayList<>();

        for(int i = 0; i < 7; i++){
            if(i <= dates.size()){
                res.add(dates.get(i));
            }
        }

        return res;
    }

}
