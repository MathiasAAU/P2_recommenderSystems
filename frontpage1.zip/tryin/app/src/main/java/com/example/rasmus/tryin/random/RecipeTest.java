package com.example.rasmus.tryin.random;

import android.util.SparseArray;
import android.util.SparseIntArray;

import com.example.rasmus.tryin.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// Just a some place to some recipe information before the database i running
public class RecipeTest {
    private static int idCounter = 0;
    private static List<Integer> imageID = new ArrayList<>();
    private static List<Integer> calorieCount = new ArrayList<>();
    private static List<String> mealName = new ArrayList<>();
    private static int totalCalories = 0;

    public RecipeTest() {
        // Temporary solution
        this.addRecipe(R.drawable.breakfast, 650, "Breakfast");
        this.addRecipe(R.drawable.lunch, 760, "Lunch");
        this.addRecipe(R.drawable.dinner, 1000, "Dinner");
    }

    public int getIdCounter() {
        return idCounter;
    }

    public void addRecipe(int imgID, int calories, String meal) {
        imageID.add(imgID);
        calorieCount.add(calories);
        mealName.add(meal);
        idCounter++;
        totalCalories += calories;
    }

    public int getCalories(int key) {
        return calorieCount.get(key);
    }

    public int getImgID(int key) {
        return imageID.get(key);
    }

    public String getMealName(int key) {
        return mealName.get(key);
    }


    public int getLastCalories() {
        return calorieCount.get(calorieCount.size() - 1);

    }

    public int getLastImgID() {
        return imageID.get(imageID.size() - 1);
    }

    public String getLastMealName() {
        return mealName.get(mealName.size() - 1);
    }


    public int getTotalCalories(){
        return totalCalories;
    }


}
