package com.example.nicolai.myshoppinglist;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ListView listView = (ListView) findViewById(R.id.listview);

        final List<ItemModel> items = new ArrayList<>();
        items.add(new ItemModel(false, "milk"));
        items.add(new ItemModel(false, "sausage"));
        items.add(new ItemModel(false, "chips"));

        final  CustomAdapter adapter = new CustomAdapter(this, items);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long l) {
                ItemModel model = items.get(i);

                if(model.isSelected())
                    model.setSelected(false);

                else
                    model.setSelected(true);

                items.set(i, model);

                adapter.updateRecords(items);
            }
        });

    }
}
