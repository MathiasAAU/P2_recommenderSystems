
import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DBHandler {

    // JDBC driver name and database URL
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://35.198.191.151:3306/p2?useSSL=false";

    public static int getRecipe_id() {
        return recipe_id;
    }

    public static void setRecipe_id(int recipe_id) {
        DBHandler.recipe_id = recipe_id;
    }

    static int recipe_id = 0;


    //  Database credentials
    static final String USER = "root";
    static final String PASS = "admin";

    static Connection conn = null;
    static Statement stmt = null;
    static ResultSet rs = null;

    static public void createCon(){

        //STEP 2: Register JDBC driver
        System.out.println("Registering JDBC drivers");
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        //STEP 3: Open a connection
        System.out.println("Connecting to database...");
        try {
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
/*
    static public void exeQuery(int ID, Recipe recipe) {
        //STEP 4: Execute a query
        System.out.println("Creating statement...");

        try {
            stmt = conn.createStatement();
            String sql = "SELECT title, submitter, picture_link, link, description, servings, calories, rating FROM recipe WHERE recipe_id=" + ID;
            rs = stmt.executeQuery(sql);



            //STEP 5: Extract data from result set
            while (rs.next()) {
                //Retrieve by column name
                String title = rs.getString("title");
                String submitter = rs.getString("submitter");
                String pictureLink = rs.getString("picture_link");
                String websiteLink = rs.getString("link");
                String description = rs.getString("description");
                int servings = rs.getInt("servings");
                int calories = rs.getInt("calories");
                double rating = rs.getInt("rating");

                //Initializing fields in the recipe class
                recipe.setTitle(title);
                recipe.setSubmitterName(submitter);
                recipe.setPictureLink(pictureLink);
                recipe.setWebsiteLink(websiteLink);
                recipe.setDescription(description);
                recipe.setServings(servings);
                recipe.setCalories(calories);
                recipe.setRating(rating);

            }

        } catch(SQLException e){
            e.printStackTrace();
        }
    }

    static public void exeQuery2(int ID, CookTime cookTime) {
        //STEP 4: Execute a query
        System.out.println("Creating statement...");

        try {
            stmt = conn.createStatement();
            String sql = "SELECT prep_time, cook_time, ready_in FROM time WHERE recipe_id=" + ID;
            rs = stmt.executeQuery(sql);


            //STEP 5: Extract data from result set
            while (rs.next()) {
                //Retrieve by column name
                String prep_Time = rs.getString("prep_time");
                String cook_Time = rs.getString("cook_time");
                String ready_In = rs.getString("ready_in");

                //Initializing fields in CookTime class

                cookTime.setPrepTime(prep_Time);
                cookTime.setCookTime(cook_Time);
                cookTime.setReadyIn(ready_In);


            }

        } catch(SQLException e){
            e.printStackTrace();
        }
    }

    static public void exeQuery3(int ID, Recipe recipe) {
        //STEP 4: Execute a query
        System.out.println("Creating statement...");

        try {
            stmt = conn.createStatement();
            String sql = "SELECT category_name FROM categories WHERE recipe_id=" + ID;
            rs = stmt.executeQuery(sql);

            List<String> listOfCategoryNames = new ArrayList<>();

            //STEP 5: Extract data from result set
            while (rs.next()) {
                //Retrieve by column name
                String categoryName = rs.getString("category_name");

                //Adds all the elements to a new list - that later can be initialized in Recipe class
                listOfCategoryNames.add(categoryName);



            }
            //Initialize the field categories in Recipe class
            recipe.setCategories(listOfCategoryNames);

        } catch(SQLException e){
            e.printStackTrace();
        }
    }
*/
    static public String exeQuery4(int ID) {
        //STEP 4: Execute a query
        //System.out.println("Creating statement...");
        String string = null;

        try {
            stmt = conn.createStatement();
            String sql = "SELECT ingredients_name, recipe_id FROM ingredients WHERE ingredients_id=" + ID;
            rs = stmt.executeQuery(sql);


            //STEP 5: Extract data from result set
            while (rs.next()) {
                //Retrieve by column name
                //   List<String> categoryName = Collections.singletonList(rs.getString("category_name"));
                setRecipe_id(rs.getInt("recipe_id"));
                return string = rs.getString("ingredients_name");

                //Initializing fields in Ingredients class

            }

        } catch(SQLException e){
            e.printStackTrace();
        }
        return string;
    }


    static public void writeToDatabase(double amount, String unit, int parenAmount, String parenUnit, String name){

        if(parenUnit.equals("")) { parenUnit = null; }

        try {
            String sql_ing = "INSERT INTO ingredients_formatted(amount,unit,other_unit,ingr_name,recipe_id)" + "VALUES(?,?,?,?,?)";
            PreparedStatement pstmt_ing = conn.prepareStatement(sql_ing);

            pstmt_ing.setDouble(1, amount);
            if(unit != null) {
                pstmt_ing.setString(2, unit);
            }
            else {pstmt_ing.setString(2,""); }

            if(parenAmount != 0 && parenUnit != null){
                pstmt_ing.setString(3, parenAmount + " " + parenUnit);
            }
            else {pstmt_ing.setString(3,""); }

            pstmt_ing.setString(4, name);
            pstmt_ing.setInt(5,getRecipe_id());

            int rowAffected = pstmt_ing.executeUpdate();
            if (rowAffected == 1) {
                System.out.println("Worked. Ingrediens :) " + getRecipe_id());
            }
        } catch(SQLException e){
            e.printStackTrace();
        }
    }
/*
    static public void exeQuery5(int ID, Recipe recipe) {
        //STEP 4: Execute a query
        System.out.println("Creating statement...");

        try {
            stmt = conn.createStatement();
            String sql = "SELECT directions FROM directions WHERE recipe_id=" + ID;
            rs = stmt.executeQuery(sql);

            List<String> listOfDirections = new ArrayList<>();

            //STEP 5: Extract data from result set
            while (rs.next()) {
                //Retrieve by column name
                //   List<String> categoryName = Collections.singletonList(rs.getString("category_name"));
                String recipeDir = rs.getString("directions");

                //Adds all the elements to a new list - that later can be initialized in Recipe class
                listOfDirections.add(recipeDir);

            }
            //Initialize the field directions in Recipe class
            recipe.setDirections(listOfDirections);

        } catch(SQLException e){
            e.printStackTrace();
        }
    }

    static public void exeQuery6(int ID, Review review) {
        //STEP 4: Execute a query
        System.out.println("Creating statement...");

        try {
            stmt = conn.createStatement();
            String sql = "SELECT review, submitter, submitter_id, individual_rating FROM reviews WHERE recipe_id=" + ID;
            rs = stmt.executeQuery(sql);



            //STEP 5: Extract data from result set
            while (rs.next()) {
                //Retrieve by column name
                String reviewText = rs.getString("review");
                String submitterName = rs.getString("submitter");
                String submitterID = rs.getString("submitter_id");
                int individualRating = rs.getInt("individual_rating");

                //Initializing fields in the Review class
                review.setReview(reviewText);
                review.setSubmitterName(submitterName);
                review.setSubmitterID(submitterID);
                review.setRating(individualRating);

            }

        } catch(SQLException e){
            e.printStackTrace();
        }
    }
*/
    static public void closeCon () {
        // what exception to use here
        try {
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        try {
            if (stmt != null)
                stmt.close();
        } catch (SQLException se2) {
        }// nothing we can do
        try {
            if (conn != null)
                conn.close();
        } catch (SQLException se) {
            se.printStackTrace();
        }

    }

}
