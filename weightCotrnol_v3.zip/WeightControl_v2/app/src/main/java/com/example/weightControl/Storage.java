package com.example.weightControl;

import com.github.mikephil.charting.data.Entry;

import java.util.ArrayList;

public class Storage {
    static ArrayList<Entry> userWeight = new ArrayList<>();
    static ArrayList<Entry> goalWeight = new ArrayList<>();
    static private int goalWeightValue = 0;

    public int getGoalWeightValue() {
        return goalWeightValue;
    }

    public void setGoalWeightValue(int goalWeightValue) {
        this.goalWeightValue = goalWeightValue;
    }

    public Storage() {

    }

    public void intialize(){
        this.userWeight.add(new Entry(1,4));
        this.userWeight.add(new Entry(2,8));
        this.userWeight.add(new Entry(3,3));
        this.userWeight.add(new Entry(4,2));

        this.goalWeight.add(new Entry(1,9));
        this.goalWeight.add(new Entry(3,3));
        this.goalWeight.add(new Entry(6,2));
        this.goalWeight.add(new Entry(9,1));
    }

    public ArrayList<Entry> getUserWeight() {
        return userWeight;
    }

    public void setUserWeight(ArrayList<Entry> userWeight) {
        this.userWeight = userWeight;
    }

    public ArrayList<Entry> getGoalWeight() {
        return goalWeight;
    }

    public void setGoalWeight(ArrayList<Entry> goalWeight) {
        this.goalWeight = goalWeight;
    }
}
