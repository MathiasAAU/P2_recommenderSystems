import database.DBHandler;
import recipeclasses.CookTime;
import recipeclasses.Ingredients;
import recipeclasses.Recipe;
import recipeclasses.Review;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        DBHandler.createCon();
        List<Recipe> recipes = new ArrayList<>();
        List<Integer> IDs = new ArrayList<>();
        for (int i = 0; i < 1000; i++) {
            IDs.add(2357 + i);
        }

        long start = System.currentTimeMillis();
        recipes = DBHandler.getRecipesFromList(IDs);
        long end = System.currentTimeMillis();

        double res = (double) (end - start) / 1000;
        System.out.println("It took " + res + " seconds to import\n");

        Recipe recipe = recipes.get(0);

        System.out.println(recipe.toString());
        System.out.println("");

        CookTime cookTime = recipe.getTime();
        System.out.println(cookTime.toString());
        System.out.println("");

        for (Ingredients i : recipe.getIngredients()) {
            System.out.println(i.toString());
        }

        System.out.println("");
        for (String s : recipe.getDirections()) {
            System.out.println(s);
        }

        System.out.println("");
        for (Review r : recipe.getReviews()) {
            System.out.println(r.toString());
        }

        System.out.println("");
        for (String s : recipe.getCategories()) {
            System.out.println(s);
        }

        DBHandler.closeCon();
    }
}
