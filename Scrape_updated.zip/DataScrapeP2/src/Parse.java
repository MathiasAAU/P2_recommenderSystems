import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class Parse {

     public static void main(String args[]){
          System.out.println("running...");

          ArrayList<Document> recDoc = new ArrayList<>();
          ArrayList<Document> revDoc = new ArrayList<>();
          ArrayList<String> ingredients = new ArrayList<>();

          ArrayList<Document> catDoc = new ArrayList<>();
          ArrayList<String> categoryDoc = new ArrayList<>();


          try {

              categoryDoc = loadPages(categoryDoc);

              int recCounter = 0;


              for (int t = 0; t < categoryDoc.size(); t++) {
                  System.out.println("Page: " + (t+1));
                  catDoc.add(Jsoup.connect(categoryDoc.get(t)).get());
                  Elements recipesURL = catDoc.get(t).select(
                      ".fixed-recipe-card__title-link[href]"); //Extracts class containing a link in each recipe box

                  int revCounter = 0;


                  for (int i = 0; i < recipesURL.size(); i++) {

                      System.out.println("URL" + (i + 1) + ": " + recipesURL.get(i).text()); //Prints title of link of a recipe
                      System.out.println(recipesURL.get(i).attr("abs:href")); //Prints link to recipe
                      recDoc.add(Jsoup.connect(recipesURL.get(i).attr("abs:href")).get()); //Connects to a recipe link



                      Recipe newRecipe = new Recipe(recipesURL.get(i).text()); //Recipe name

                      newRecipe.setLink(recipesURL.get(i).attr("abs:href")); //Link to recipe

                      newRecipe.setSubmitter(recDoc.get(recCounter).select(".submitter__name").text()); //Recipe submitter

                      newRecipe.setDescription(recDoc.get(recCounter).select(".submitter__description").text()); //Recipe description
                      //System.out.println(newRecipe.getDescription());

                      Elements pictureLink = recDoc.get(recCounter).select(".hero-photo__wrap a.video-play img[src]");
                      newRecipe.setPicLink(pictureLink.get(0).attr("src"));
                      System.out.println(newRecipe.getPicLink());

                      /* Category */
                      Elements category = recDoc.get(recCounter).select(".full-page ol.breadcrumbs li a span.toggle-similar__title");

                      while(!(category.last().ownText().equals("Recipes")))
                      {
                          newRecipe.tags.add(category.last().ownText());
                          category.remove(category.last());
                      }
                      System.out.println(newRecipe.tags);

                      /* Directions */
                      Elements direction = recDoc.get(recCounter).select(
                          ".recipe-directions__list li.step span.recipe-directions__list--item"); //Recipe directions

                      for (int j = 0; j < direction.size() - 1; j++) {
                          newRecipe.directions.add(direction.get(j).text()); //Stores recipe directions in order
                      }
                      //System.out.println(newRecipe.getDirections());

                      /* Prep and cook time */
                      Elements cookTime = recDoc.get(t).select(".prepTime__item time[datetime]");

                      for (Element aCookTime : cookTime) {
                          newRecipe.cookTime.add(aCookTime.attr("datetime"));
                          //System.out.println(newRecipe.cookTime.get(k));
                      }

                      /* Servings */
                      Elements servings = recDoc.get(recCounter).select(
                          ".recipe-ingredients__header__toggles meta[itemprop=recipeYield]"); //Racipe servings
                      newRecipe.setServings(servings.get(0).attr("content")); //Attribute containing servings amount
                      //System.out.println(newRecipe.getServings());

                      /* Calories */
                      newRecipe.setCalories(recDoc.get(recCounter).select(".calorie-count").text()); //Recipe calories
                      //System.out.println(newRecipe.getCalories());


                      /* Reviews */
                      /*Elements reviewsURL = recDoc.get(i).select(
                          ".review-container.clearfix div.review-detail a.review-detail__link[href]"); //Extracts full review links

                      for (int h = 0; h < reviewsURL.size(); h++) {
                          revDoc.add(Jsoup.connect(reviewsURL.get(h).attr("abs:href")).get()); //Connects to review link*/

                          /* Submitter username */
                          /*Elements revSubmitter = revDoc.get(revCounter).select(
                              ".recipe-details-cook-stats-container a ul.cook-details li.cook-info h4"); //Review submitter
                          Review newReview = new Review(revSubmitter.get(0).ownText());

                          /* Submitter ID */
                          /*Elements submitID = revDoc.get(revCounter).select(".reviewer-info.clearfix div.recipe-details-cook-stats-container a");
                          newReview.setSubmitterID(submitID.get(0).attr("href")); //Review submitters id (link to profile)
                          //System.out.println(newReview.getSubmitter() + " " + newReview.getSubmitterID());

                          /* Rating value of the review */
                          /*Elements revRating = revDoc.get(revCounter).select(
                              ".review-detail.clearfix div.review-detail__stars meta[itemprop=ratingValue]");
                          newReview.setRating(revRating.get(0).attr("content")); //Attribute containing review rating
                          //System.out.println(newReview.getRating());

                          /* Text of review */
                          /*Elements reviews = revDoc.get(revCounter).select(
                              ".review-container div.review-detail.clearfix p"); //Extracts text in full review
                          newReview.setReviewText(reviews.get(0).ownText());
                          //System.out.println(newReview.getReviewText());

                          /* Link reviews to recipe */
                          /*newRecipe.reviewers.add(newReview.getSubmitterID());
                          //System.out.println(newRecipe.reviewers);

                          revCounter++;
                          TimeUnit.MILLISECONDS.sleep(1000);
                      }


                      /* TODO: Load more reviews - see this: https://stackoverflow.com/questions/32752246/programmaticaly-click-html-button-using-java */


                      /* Rating */
                      Elements rating = recDoc.get(recCounter).select(
                          ".recipe-summary.clearfix div.recipe-summary__stars " +
                              "span.aggregate-rating meta[itemprop=ratingValue]"); //Extracts class containing recipe rating
                      newRecipe.setRating(rating.get(0).attr("content"));
                      //System.out.println("Rating: " + newRecipe.getRating());

                      /* Ingredients */
                      ingredients.add(recDoc.get(recCounter).select(".checkList__line").text()); //Gets all ingredients in one long string
                      String[] ingredientsSplit = ingredients.get(recCounter).split(" ADVERTISEMENT "); //Splits up the string to the different ingredients
                      for (String anIngredientsSplit : ingredientsSplit) {
                          if (anIngredientsSplit.compareTo("Add all ingredients to list") != 0) {
                              //System.out.println(ingredientsSplit[j]);
                          }
                      }


                      /* Separate recipes in printing and wait a second */
                      recCounter++;
                      System.out.println();
                      TimeUnit.MILLISECONDS.sleep(1000);

                  }
              }


              /* Prints stack trace if exceptions occur */
              } catch(IOException | InterruptedException e) {
              e.printStackTrace();
          }

          System.out.println("done");
     }



     private static ArrayList<String> loadPages(ArrayList<String> loaded){
         /* ***** MEAL CATEGORIES ***** */
         /* ***** APPETIZERS & SNACKS ***** */
         loaded.add("https://www.allrecipes.com/recipes/76/appetizers-and-snacks/?page=1");
         loaded.add("https://www.allrecipes.com/recipes/76/appetizers-and-snacks/?page=2");
         loaded.add("https://www.allrecipes.com/recipes/76/appetizers-and-snacks/?page=3");
         loaded.add("https://www.allrecipes.com/recipes/76/appetizers-and-snacks/?page=4");
         loaded.add("https://www.allrecipes.com/recipes/76/appetizers-and-snacks/?page=5");
         loaded.add("https://www.allrecipes.com/recipes/76/appetizers-and-snacks/?page=6");
         loaded.add("https://www.allrecipes.com/recipes/76/appetizers-and-snacks/?page=7");
         loaded.add("https://www.allrecipes.com/recipes/76/appetizers-and-snacks/?page=8");
         loaded.add("https://www.allrecipes.com/recipes/76/appetizers-and-snacks/?page=9");
         loaded.add("https://www.allrecipes.com/recipes/76/appetizers-and-snacks/?page=10");

         /* ***** BREAKFAST & BRUNCH ***** */
         loaded.add("https://www.allrecipes.com/recipes/78/breakfast-and-brunch/?page=1");
         loaded.add("https://www.allrecipes.com/recipes/78/breakfast-and-brunch/?page=2");
         loaded.add("https://www.allrecipes.com/recipes/78/breakfast-and-brunch/?page=3");
         loaded.add("https://www.allrecipes.com/recipes/78/breakfast-and-brunch/?page=4");
         loaded.add("https://www.allrecipes.com/recipes/78/breakfast-and-brunch/?page=5");
         loaded.add("https://www.allrecipes.com/recipes/78/breakfast-and-brunch/?page=6");
         loaded.add("https://www.allrecipes.com/recipes/78/breakfast-and-brunch/?page=7");
         loaded.add("https://www.allrecipes.com/recipes/78/breakfast-and-brunch/?page=8");
         loaded.add("https://www.allrecipes.com/recipes/78/breakfast-and-brunch/?page=9");
         loaded.add("https://www.allrecipes.com/recipes/78/breakfast-and-brunch/?page=10");

         /* ***** DESSERTS ***** */
         loaded.add("https://www.allrecipes.com/recipes/79/desserts/?page=1");
         loaded.add("https://www.allrecipes.com/recipes/79/desserts/?page=2");
         loaded.add("https://www.allrecipes.com/recipes/79/desserts/?page=3");
         loaded.add("https://www.allrecipes.com/recipes/79/desserts/?page=4");
         loaded.add("https://www.allrecipes.com/recipes/79/desserts/?page=5");
         loaded.add("https://www.allrecipes.com/recipes/79/desserts/?page=6");
         loaded.add("https://www.allrecipes.com/recipes/79/desserts/?page=7");
         loaded.add("https://www.allrecipes.com/recipes/79/desserts/?page=8");
         loaded.add("https://www.allrecipes.com/recipes/79/desserts/?page=9");
         loaded.add("https://www.allrecipes.com/recipes/79/desserts/?page=10");

         /* ***** DINNER ***** */
         loaded.add("https://www.allrecipes.com/recipes/17562/dinner/?page=1");
         loaded.add("https://www.allrecipes.com/recipes/17562/dinner/?page=2");
         loaded.add("https://www.allrecipes.com/recipes/17562/dinner/?page=3");
         loaded.add("https://www.allrecipes.com/recipes/17562/dinner/?page=4");
         loaded.add("https://www.allrecipes.com/recipes/17562/dinner/?page=5");
         loaded.add("https://www.allrecipes.com/recipes/17562/dinner/?page=6");
         loaded.add("https://www.allrecipes.com/recipes/17562/dinner/?page=7");
         loaded.add("https://www.allrecipes.com/recipes/17562/dinner/?page=8");
         loaded.add("https://www.allrecipes.com/recipes/17562/dinner/?page=9");
         loaded.add("https://www.allrecipes.com/recipes/17562/dinner/?page=10");

         /* ***** DRINKS ***** */
         loaded.add("https://www.allrecipes.com/recipes/77/drinks/?page=1");
         loaded.add("https://www.allrecipes.com/recipes/77/drinks/?page=2");
         loaded.add("https://www.allrecipes.com/recipes/77/drinks/?page=3");
         loaded.add("https://www.allrecipes.com/recipes/77/drinks/?page=4");
         loaded.add("https://www.allrecipes.com/recipes/77/drinks/?page=5");
         loaded.add("https://www.allrecipes.com/recipes/77/drinks/?page=6");
         loaded.add("https://www.allrecipes.com/recipes/77/drinks/?page=7");
         loaded.add("https://www.allrecipes.com/recipes/77/drinks/?page=8");
         loaded.add("https://www.allrecipes.com/recipes/77/drinks/?page=9");
         loaded.add("https://www.allrecipes.com/recipes/77/drinks/?page=10");


         /* ***** WORLD CUISINE ***** */
         /* ***** AFRICAN ***** */
         loaded.add("https://www.allrecipes.com/recipes/226/world-cuisine/african/?page=1");
         loaded.add("https://www.allrecipes.com/recipes/226/world-cuisine/african/?page=2");
         loaded.add("https://www.allrecipes.com/recipes/226/world-cuisine/african/?page=3");
         loaded.add("https://www.allrecipes.com/recipes/226/world-cuisine/african/?page=4");
         loaded.add("https://www.allrecipes.com/recipes/226/world-cuisine/african/?page=5");
         loaded.add("https://www.allrecipes.com/recipes/226/world-cuisine/african/?page=6");
         loaded.add("https://www.allrecipes.com/recipes/226/world-cuisine/african/?page=7");
         loaded.add("https://www.allrecipes.com/recipes/226/world-cuisine/african/?page=8");
         loaded.add("https://www.allrecipes.com/recipes/226/world-cuisine/african/?page=9");
         loaded.add("https://www.allrecipes.com/recipes/226/world-cuisine/african/?page=10");

         /* ***** ASIAN ***** */
         loaded.add("https://www.allrecipes.com/recipes/227/world-cuisine/asian/?page=1");
         loaded.add("https://www.allrecipes.com/recipes/227/world-cuisine/asian/?page=2");
         loaded.add("https://www.allrecipes.com/recipes/227/world-cuisine/asian/?page=3");
         loaded.add("https://www.allrecipes.com/recipes/227/world-cuisine/asian/?page=4");
         loaded.add("https://www.allrecipes.com/recipes/227/world-cuisine/asian/?page=5");
         loaded.add("https://www.allrecipes.com/recipes/227/world-cuisine/asian/?page=6");
         loaded.add("https://www.allrecipes.com/recipes/227/world-cuisine/asian/?page=7");
         loaded.add("https://www.allrecipes.com/recipes/227/world-cuisine/asian/?page=8");
         loaded.add("https://www.allrecipes.com/recipes/227/world-cuisine/asian/?page=9");
         loaded.add("https://www.allrecipes.com/recipes/227/world-cuisine/asian/?page=10");

         /* ***** AUSTRALIAN & NEW ZEALANDER ***** */
         loaded.add("https://www.allrecipes.com/recipes/228/world-cuisine/australian-and-new-zealander/?page=1");
         loaded.add("https://www.allrecipes.com/recipes/228/world-cuisine/australian-and-new-zealander/?page=2");
         loaded.add("https://www.allrecipes.com/recipes/228/world-cuisine/australian-and-new-zealander/?page=3");
         loaded.add("https://www.allrecipes.com/recipes/228/world-cuisine/australian-and-new-zealander/?page=4");
         loaded.add("https://www.allrecipes.com/recipes/228/world-cuisine/australian-and-new-zealander/?page=5");
         loaded.add("https://www.allrecipes.com/recipes/228/world-cuisine/australian-and-new-zealander/?page=6");
         loaded.add("https://www.allrecipes.com/recipes/228/world-cuisine/australian-and-new-zealander/?page=7");
         loaded.add("https://www.allrecipes.com/recipes/228/world-cuisine/australian-and-new-zealander/?page=8");
         loaded.add("https://www.allrecipes.com/recipes/228/world-cuisine/australian-and-new-zealander/?page=9");
         loaded.add("https://www.allrecipes.com/recipes/228/world-cuisine/australian-and-new-zealander/?page=10");

         /* ***** EUROPEAN ***** */
         loaded.add("https://www.allrecipes.com/recipes/231/world-cuisine/european/?page=1");
         loaded.add("https://www.allrecipes.com/recipes/231/world-cuisine/european/?page=2");
         loaded.add("https://www.allrecipes.com/recipes/231/world-cuisine/european/?page=3");
         loaded.add("https://www.allrecipes.com/recipes/231/world-cuisine/european/?page=4");
         loaded.add("https://www.allrecipes.com/recipes/231/world-cuisine/european/?page=5");
         loaded.add("https://www.allrecipes.com/recipes/231/world-cuisine/european/?page=6");
         loaded.add("https://www.allrecipes.com/recipes/231/world-cuisine/european/?page=7");
         loaded.add("https://www.allrecipes.com/recipes/231/world-cuisine/european/?page=8");
         loaded.add("https://www.allrecipes.com/recipes/231/world-cuisine/european/?page=9");
         loaded.add("https://www.allrecipes.com/recipes/231/world-cuisine/european/?page=10");

         /* ***** LATIN AMERICAN ***** */
         loaded.add("https://www.allrecipes.com/recipes/237/world-cuisine/latin-american/?page=1");
         loaded.add("https://www.allrecipes.com/recipes/237/world-cuisine/latin-american/?page=2");
         loaded.add("https://www.allrecipes.com/recipes/237/world-cuisine/latin-american/?page=3");
         loaded.add("https://www.allrecipes.com/recipes/237/world-cuisine/latin-american/?page=4");
         loaded.add("https://www.allrecipes.com/recipes/237/world-cuisine/latin-american/?page=5");
         loaded.add("https://www.allrecipes.com/recipes/237/world-cuisine/latin-american/?page=6");
         loaded.add("https://www.allrecipes.com/recipes/237/world-cuisine/latin-american/?page=7");
         loaded.add("https://www.allrecipes.com/recipes/237/world-cuisine/latin-american/?page=8");
         loaded.add("https://www.allrecipes.com/recipes/237/world-cuisine/latin-american/?page=9");
         loaded.add("https://www.allrecipes.com/recipes/237/world-cuisine/latin-american/?page=10");

         /* ***** MIDDLE EASTERN ***** */
         loaded.add("https://www.allrecipes.com/recipes/235/world-cuisine/middle-eastern/?page=1");
         loaded.add("https://www.allrecipes.com/recipes/235/world-cuisine/middle-eastern/?page=2");
         loaded.add("https://www.allrecipes.com/recipes/235/world-cuisine/middle-eastern/?page=3");
         loaded.add("https://www.allrecipes.com/recipes/235/world-cuisine/middle-eastern/?page=4");
         loaded.add("https://www.allrecipes.com/recipes/235/world-cuisine/middle-eastern/?page=5");
         loaded.add("https://www.allrecipes.com/recipes/235/world-cuisine/middle-eastern/?page=6");
         loaded.add("https://www.allrecipes.com/recipes/235/world-cuisine/middle-eastern/?page=7");
         loaded.add("https://www.allrecipes.com/recipes/235/world-cuisine/middle-eastern/?page=8");
         loaded.add("https://www.allrecipes.com/recipes/235/world-cuisine/middle-eastern/?page=9");
         loaded.add("https://www.allrecipes.com/recipes/235/world-cuisine/middle-eastern/?page=10");

         /* ***** MEDITERRANEAN ***** */
         loaded.add("https://www.allrecipes.com/recipes/16704/healthy-recipes/mediterranean-diet/?page=1");
         loaded.add("https://www.allrecipes.com/recipes/16704/healthy-recipes/mediterranean-diet/?page=2");
         loaded.add("https://www.allrecipes.com/recipes/16704/healthy-recipes/mediterranean-diet/?page=3");
         loaded.add("https://www.allrecipes.com/recipes/16704/healthy-recipes/mediterranean-diet/?page=4");
         loaded.add("https://www.allrecipes.com/recipes/16704/healthy-recipes/mediterranean-diet/?page=5");
         loaded.add("https://www.allrecipes.com/recipes/16704/healthy-recipes/mediterranean-diet/?page=6");
         loaded.add("https://www.allrecipes.com/recipes/16704/healthy-recipes/mediterranean-diet/?page=7");
         loaded.add("https://www.allrecipes.com/recipes/16704/healthy-recipes/mediterranean-diet/?page=8");
         loaded.add("https://www.allrecipes.com/recipes/16704/healthy-recipes/mediterranean-diet/?page=9");
         loaded.add("https://www.allrecipes.com/recipes/16704/healthy-recipes/mediterranean-diet/?page=10");

         /* ***** US ***** */
         loaded.add("https://www.allrecipes.com/recipes/236/us-recipes/?page=1");
         loaded.add("https://www.allrecipes.com/recipes/236/us-recipes/?page=2");
         loaded.add("https://www.allrecipes.com/recipes/236/us-recipes/?page=3");
         loaded.add("https://www.allrecipes.com/recipes/236/us-recipes/?page=4");
         loaded.add("https://www.allrecipes.com/recipes/236/us-recipes/?page=5");
         loaded.add("https://www.allrecipes.com/recipes/236/us-recipes/?page=6");
         loaded.add("https://www.allrecipes.com/recipes/236/us-recipes/?page=7");
         loaded.add("https://www.allrecipes.com/recipes/236/us-recipes/?page=8");
         loaded.add("https://www.allrecipes.com/recipes/236/us-recipes/?page=9");
         loaded.add("https://www.allrecipes.com/recipes/236/us-recipes/?page=10");


         return loaded;
     }

}
