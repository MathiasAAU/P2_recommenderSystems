package userclasses;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class GoalTest {

    @Test
    void bmiTest01(){
        LocalUser localUser = new LocalUser();
        localUser.setHeight(180);
        localUser.setWeight(80);
        assertEquals(localUser.getWeight() / ((localUser.getHeight() / 100) * (localUser.getHeight() / 100)),
                localUser.calcBMI());
    }

    @Test
    void bmiTest02(){
        LocalUser localUser = new LocalUser();
        localUser.setHeight(200);
        localUser.setWeight(100);
        assertEquals(localUser.getWeight() / ((localUser.getHeight() / 100) * (localUser.getHeight() / 100)),
                localUser.calcBMI());
    }

    @Test
    void calOffsetTest01(){
        LocalUser localUser = new LocalUser();
        localUser.setHeight(200);
        localUser.setWeight(100);
        assertEquals((localUser.calcBMI() * localUser.calcBMI()) - (localUser.calcBMI() * 5),
                localUser.getGoal().calOffset(localUser.calcBMI()));
    }

    @Test
    void calOffsetTest02(){
        LocalUser localUser = new LocalUser();
        localUser.setHeight(200);
        localUser.setWeight(200);
        assertNotEquals((localUser.calcBMI() * localUser.calcBMI()) - (localUser.calcBMI() * 5),
                localUser.getGoal().calOffset(localUser.calcBMI()));
    }

    @Test
    void calcBMRTest01(){
        LocalUser localUser = new LocalUser();
        localUser.setSex("Male");
        localUser.setHeight(200);
        localUser.setWeight(200);
        assertEquals(88.362 + (13.397 * localUser.getWeight()) + (4.799 * localUser.getHeight()) - (5.677 * localUser.getAge()),
                localUser.getGoal().RHB_Equation(localUser));
    }

    @Test
    void calcBMRTest02(){
        LocalUser localUser = new LocalUser();
        localUser.setSex("Female");
        localUser.setHeight(200);
        localUser.setWeight(200);
        assertNotEquals(88.362 + (13.397 * localUser.getWeight()) + (4.799 * localUser.getHeight()) - (5.677 * localUser.getAge()),
                localUser.getGoal().RHB_Equation(localUser));
    }

    @Test
    void calcBMRTest03(){
        LocalUser localUser = new LocalUser();
        localUser.setSex("Female");
        localUser.setHeight(200);
        localUser.setWeight(200);
        assertEquals((447.593 + (9.247 * localUser.getWeight()) + (3.098 * localUser.getHeight()) -
                (4.330 * localUser.getAge())), localUser.getGoal().RHB_Equation(localUser));
    }


    @Test
    void lessCaloriesPerDayTest01() {
        LocalUser localUser = new LocalUser();
        localUser.setAge(25);
        localUser.setSex("Male");
        localUser.setHeight(200);
        localUser.setWeight(200);
        localUser.setGoalWeight(100);
        localUser.getGoal().calcCaloriesPerDay(localUser);
        assertEquals(localUser.getGoal().calOffset(localUser.calcBMI()), localUser.getCalorieDeficit());
    }

    @Test
    void lessCaloriesPerDayTest02() {
        LocalUser localUser = new LocalUser();
        localUser.setAge(25);
        localUser.setSex("Male");
        localUser.setHeight(200);
        localUser.setWeight(120);
        localUser.setGoalWeight(100);
        localUser.getGoal().calcCaloriesPerDay(localUser);
        assertEquals(localUser.getGoal().calOffset(localUser.calcBMI()), localUser.getCalorieDeficit());
    }

    @Test
    void lessCaloriesPerDayTest03() {
        LocalUser localUser = new LocalUser();
        localUser.setAge(25);
        localUser.setSex("Male");
        localUser.setHeight(200);
        localUser.setWeight(200);
        localUser.setGoalWeight(100);
        localUser.getGoal().calcCaloriesPerDay(localUser);
        assertEquals(1000, localUser.getCalorieDeficit());
    }

    @Test
    void goalReachedTest01() {
        LocalUser localUser = new LocalUser();
        LocalUser localUser1 = new LocalUser();
        localUser.setAge(25);
        localUser.setSex("Male");
        localUser.setHeight(200);
        localUser.setWeight(200);
        localUser.setGoalWeight(150);
        localUser1.setAge(25);
        localUser1.setSex("Male");
        localUser1.setHeight(200);
        localUser1.setWeight(200);
        localUser1.setGoalWeight(200);
        localUser.getGoal().calcCaloriesPerDay(localUser);
        localUser1.getGoal().calcCaloriesPerDay(localUser1);
        assertNotEquals(localUser1.getCaloriesPerDay(), localUser.getCaloriesPerDay());
    }

    @Test
    void goalReachedTest02() {
        LocalUser localUser = new LocalUser();
        LocalUser localUser1 = new LocalUser();
        localUser.setAge(25);
        localUser.setSex("Male");
        localUser.setHeight(200);
        localUser.setWeight(100);
        localUser.setGoalWeight(100);
        localUser1.setAge(25);
        localUser1.setSex("Female");
        localUser1.setHeight(200);
        localUser1.setWeight(100);
        localUser1.setGoalWeight(100);
        localUser.getGoal().calcCaloriesPerDay(localUser);
        localUser1.getGoal().calcCaloriesPerDay(localUser1);
        assertEquals(localUser1.getCalorieDeficit(), localUser.getCalorieDeficit());
    }


    @Test
    void calcCaloriesTest01() {
        LocalUser localUser = new LocalUser();
        localUser.setAge(25);
        localUser.setSex("Male");
        localUser.setHeight(200);
        localUser.setWeight(200);
        localUser.setGoalWeight(100);
        localUser.getGoal().calcCaloriesPerDay(localUser);
        assertEquals((int) (localUser.getGoal().RHB_Equation(localUser) * localUser.getExerciseLvl() -
                localUser.getCalorieDeficit()), localUser.getCaloriesPerDay());
    }

    @Test
    void calcCaloriesTest02() {
        LocalUser localUser = new LocalUser();
        localUser.setAge(25);
        localUser.setSex("Female");
        localUser.setHeight(200);
        localUser.setWeight(100);
        localUser.setGoalWeight(80);
        localUser.getGoal().calcCaloriesPerDay(localUser);
        assertEquals((int) (localUser.getGoal().RHB_Equation(localUser) * localUser.getExerciseLvl() -
                localUser.getCalorieDeficit()),localUser.getCaloriesPerDay());
    }

    @Test
    void calToKiloTest01(){
        LocalUser localUser = new LocalUser();
        assertEquals(500/1102.3 , localUser.getGoal().calToKilo(500));
    }

    @Test
    void calToKiloTest02(){
        LocalUser localUser = new LocalUser();
        assertEquals(800/1102.3 , localUser.getGoal().calToKilo(800));
    }

    @Test
    void getDateTest01(){
        LocalUser localUser = new LocalUser();
        localUser.setWeight(100);
        localUser.getGoal().addUserWeight(LocalDate.now(), 100);
        localUser.getGoal().addUserWeight(LocalDate.of(2001,9,9), 102);
        localUser.getGoal().addUserWeight(LocalDate.of(2018,1,1), 113);
        localUser.getGoal().addUserWeight(LocalDate.of(2014,5,5), 122);
        assertEquals(LocalDate.now(), localUser.getGoal().getLastDate(
                localUser.getGoal().getUserWeight(), localUser.getWeight()));
    }

    @Test
    void getDateTest02(){
        LocalUser localUser = new LocalUser();
        localUser.setWeight(101);
        localUser.getGoal().addUserWeight(LocalDate.of(2001,9,9), 102);
        localUser.getGoal().addUserWeight(LocalDate.of(2018,1,1), 101);
        localUser.getGoal().addUserWeight(LocalDate.of(2014,3,3), 122);
        assertEquals(LocalDate.of(2018,1,1), localUser.getGoal().getLastDate(
                localUser.getGoal().getUserWeight(), localUser.getWeight()));
    }

    @Test
    void getDateTest03(){
        LocalUser localUser = new LocalUser();
        localUser.setGoalWeight(120);
        localUser.getGoal().addGoalWeight(LocalDate.of(2001,9,9), 102);
        localUser.getGoal().addGoalWeight(LocalDate.of(2018,1,1), 101);
        localUser.getGoal().addGoalWeight(LocalDate.of(2014,3,3), 120);
        assertEquals(LocalDate.of(2014,3,3), localUser.getGoal().getLastDate(
                localUser.getGoal().getGoalWeight(), localUser.getGoalWeight()));
    }

    @Test
    void getDateTest04(){
        LocalUser localUser = new LocalUser();
        localUser.setGoalWeight(108);
        localUser.getGoal().addGoalWeight(LocalDate.of(2001,9,9), 108);
        localUser.getGoal().addGoalWeight(LocalDate.of(2018,1,1), 101);
        localUser.getGoal().addGoalWeight(LocalDate.of(2014,3,3), 120);
        assertEquals(LocalDate.of(2001,9,9), localUser.getGoal().getLastDate(
                localUser.getGoal().getGoalWeight(), localUser.getGoalWeight()));
    }

    @Test
    void calcGoalDateTest01(){
        LocalUser localUser = new LocalUser();
        localUser.setAge(25);
        localUser.setSex("Male");
        localUser.setHeight(200);
        localUser.setWeight(200);
        localUser.setGoalWeight(150);
        localUser.getGoal().addUserWeight(LocalDate.now(), localUser.getWeight());
        localUser.getGoal().addGoalWeight(LocalDate.now(), localUser.getGoalWeight());
        int weeks = (int) ((localUser.getWeight() - localUser.getGoalWeight()) / 0.90718474);
        assertEquals(LocalDate.now().plusWeeks(weeks + 1), localUser.getGoal().calcGoalDate(localUser));
    }

    @Test
    void calcGoalDateTest02(){
        LocalUser localUser2 = new LocalUser();
        localUser2.setAge(25);
        localUser2.setSex("Male");
        localUser2.setHeight(200);
        localUser2.setWeight(120);
        localUser2.setGoalWeight(80);
        localUser2.getGoal().addUserWeight(LocalDate.of(2005,1,1), localUser2.getWeight());
        localUser2.getGoal().addGoalWeight(LocalDate.of(2005,1,1), localUser2.getGoalWeight());
        int weeks = (int) ((localUser2.getWeight() - localUser2.getGoalWeight()) / 0.90718474);
        assertNotEquals(LocalDate.of(2005,1,1).plusWeeks(weeks + 1), localUser2.getGoal().calcGoalDate(localUser2));
    }

    @Test
    void calcGoalDateTest03(){
        LocalUser localUser = new LocalUser();
        localUser.getGoal().getUserWeight().clear();
        localUser.getGoal().getGoalWeight().clear();
        localUser.setAge(25);
        localUser.setSex("Female");
        localUser.setHeight(200);
        localUser.setWeight(300);
        localUser.setGoalWeight(200);
        localUser.getGoal().addUserWeight(LocalDate.of(2006,1,1), localUser.getWeight());
        localUser.getGoal().addUserWeight(LocalDate.of(2006,3,1), localUser.getWeight());
        localUser.getGoal().addGoalWeight(LocalDate.of(2006,12,1), localUser.getGoalWeight());
        int weeks = (int) ((localUser.getWeight() - localUser.getGoalWeight()) / 0.90718474);
        assertEquals(LocalDate.of(2006,1,1).plusWeeks(weeks + 1), localUser.getGoal().calcGoalDate(localUser));
    }

    @Test
    void getFirstDateTest01(){
        LocalUser local = new LocalUser();
        local.getGoal().getUserWeight().clear();
        local.getGoal().addUserWeight(LocalDate.of(2006,3,1), 100);
        local.getGoal().addUserWeight(LocalDate.of(2006,8,1), 100);
        local.getGoal().addUserWeight(LocalDate.of(2007,1,1), 100);
        assertEquals(LocalDate.of(2006,3,1), local.getGoal().getFirstDate(local.getGoal().getUserWeight()));
    }

    @Test
    void getFirstDateTest02(){
        LocalUser localUser = new LocalUser();
        localUser.getGoal().getUserWeight().clear();
        localUser.getGoal().addUserWeight(LocalDate.of(2018,2,1), 100);
        localUser.getGoal().addUserWeight(LocalDate.of(2018,1,7), 100);
        localUser.getGoal().addUserWeight(LocalDate.of(2018,1,6), 100);
        assertEquals(LocalDate.of(2018,1,6), localUser.getGoal().getFirstDate(localUser.getGoal().getUserWeight()));
    }


}