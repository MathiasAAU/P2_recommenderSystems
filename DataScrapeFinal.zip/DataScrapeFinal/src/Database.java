import java.sql.*;

public class Database {
    // JDBC driver name and database URL
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/p2";

    //  Database credentials
    static final String USER = "root";
    static final String PASS = "pw123";


    public void write(Recipe recipe){
        Connection conn = null;
        Statement stmt = null;
        try{
            //STEP 2: Register JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            //STEP 3: Open a connection
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);

            //STEP 4: Execute a query
            System.out.println("Creating statement...");
            stmt = conn.createStatement();

            String sql = "INSERT INTO recipe(title,submitter,picture_link,link,description,servings,calories,rating)"
                    + "VALUES(?,?,?,?,?,?,?,?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            //Recipe title
            pstmt.setString(1, recipe.getName());
            //Submitter name
            pstmt.setString(2, recipe.getSubmitter());
            //Category name
            pstmt.setString(3, recipe.getPicLink());
            //Link to the recipe
            pstmt.setString(4, recipe.getLink());
            //Recipe description
            pstmt.setString(5, recipe.getDescription());
            //Number of servings
            pstmt.setInt(6, recipe.getServings());
            //Amount of calories
            pstmt.setInt(7, recipe.getCalories());
            //The total rating of the recipe
            pstmt.setFloat(8, recipe.getRating());

            int rowAffected = pstmt.executeUpdate();
            if (rowAffected == 1) {
                System.out.println("Worked. POGGERS :)");
            }

            String sql_recipeID = "SELECT recipe_id FROM recipe";
            ResultSet rs = stmt.executeQuery(sql_recipeID);
            int before = rs.getRow();

            /* *** Ingrediens *** */
            String[] ingredients = recipe.getIngredients();

            String sql_ing = "INSERT INTO ingredients(ingredients_name,recipe_id)" + "VALUES(?,?)";
            PreparedStatement pstmt_ing = conn.prepareStatement(sql_ing);

            for(int i = 0; i < ingredients.length - 2; i++) {
                pstmt_ing.setString(1, ingredients[i]);
                while (rs.next()) {
                    int recipe_id = rs.getInt("recipe_id");
                    pstmt_ing.setInt(2, recipe_id);
                }
                int rowAffected2 = pstmt_ing.executeUpdate();
                if (rowAffected2 == 1) {
                    System.out.println("Worked. Ingrediens :)");
                }
            }
            //int after = rs.getRow();
            //System.out.println("before: " + before + "after " + after);

            /* *** Directions *** */
            String sql_dir = "INSERT INTO directions(directions,recipe_id)" + "VALUES(?,?)";
            PreparedStatement pstmt_dir = conn.prepareStatement(sql_dir);
            for(String aDirection : recipe.directions) {
                pstmt_dir.setString(1, aDirection);

                rs.absolute(before);
                while (rs.next()) {
                    int recipe_id = rs.getInt("recipe_id");
                    pstmt_dir.setInt(2, recipe_id);
                }

                int rowAffected3 = pstmt_dir.executeUpdate();
                if (rowAffected3 == 1) {
                    System.out.println("Worked. Directions :)");
                }
            }

            /* *** Time *** */
            String sql_time = "INSERT INTO time(prep_time,cook_time,ready_in,recipe_id)" + "VALUES(?,?,?,?)";
            PreparedStatement pstmt_time = conn.prepareStatement(sql_time);
            pstmt_time.setString(1, recipe.cookTime.get(0).replace("PT",""));
            pstmt_time.setString(2, recipe.cookTime.get(1).replace("PT",""));
            if(recipe.cookTime.size() == 3) {
                pstmt_time.setString(3, recipe.cookTime.get(2).replace("PT",""));
            }
            else{
                pstmt_time.setString(3, null);
            }

            rs.absolute(before);
            while (rs.next()) {
                int recipe_id = rs.getInt("recipe_id");
                pstmt_time.setInt(4, recipe_id);
            }

            int rowAffected4 = pstmt_time.executeUpdate();
            if (rowAffected4 == 1) {
                System.out.println("Worked. Time :)");
            }



            /* *** Reviews *** */
            String sql_reviews = "INSERT INTO reviews(review,submitter,submitter_id,individual_rating,recipe_id)" + "VALUES(?,?,?,?,?)";
            PreparedStatement pstmt_reviews = conn.prepareStatement(sql_reviews);

            for(Review review : recipe.reviewText) {
                pstmt_reviews.setString(1, review.getReviewText());
                pstmt_reviews.setString(2, review.getSubmitter());
                pstmt_reviews.setString(3, review.getSubmitterID());
                pstmt_reviews.setInt(4, review.getRating());

                rs.absolute(before);
                while (rs.next()) {
                    int recipe_id = rs.getInt("recipe_id");
                    pstmt_reviews.setInt(5, recipe_id);
                }

                int rowAffected5 = pstmt_reviews.executeUpdate();
                if (rowAffected5 == 1) {
                    System.out.println("Worked. Reviews :)");
                }
            }

            /* *** Categories *** */
            String sql_cat = "INSERT INTO categories(category_name,recipe_id)" + "VALUES(?,?)";
            PreparedStatement pstmt_cat = conn.prepareStatement(sql_cat);
            for(String aCategory : recipe.tags) {
                pstmt_cat.setString(1, aCategory);

                rs.absolute(before);
                while (rs.next()) {
                    int recipe_id = rs.getInt("recipe_id");
                    pstmt_cat.setInt(2, recipe_id);
                }

                int rowAffected6 = pstmt_cat.executeUpdate();
                if (rowAffected6 == 1) {
                    System.out.println("Worked. Categories :)");
                }
            }

            rs.close();


            //STEP 6: Clean-up environment
            stmt.close();
            conn.close();
        }catch(SQLException se){
            //Handle errors for JDBC
            se.printStackTrace();
        }catch(Exception e){
            //Handle errors for Class.forName
            e.printStackTrace();
        }finally{
            //finally block used to close resources
            try{
                if(stmt!=null)
                    stmt.close();
            }catch(SQLException se2){
            }// nothing we can do
            try{
                if(conn!=null)
                    conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }//end finally try
        }//end try
        System.out.println("Goodbye!");
    }


}
