import java.util.ArrayList;

public class Recipe {

    private String name;
    private String submitter;
    private String link;
    private String description;
    private String servings;
    private String calories;
    private String rating;
    private String picLink;

    private String[] ingredients;
    ArrayList<String> directions = new ArrayList<>();
    ArrayList<String> cookTime = new ArrayList<>();
    ArrayList<String> reviewers = new ArrayList<>();
    ArrayList<Review> reviewText = new ArrayList<>();
    ArrayList<String> tags = new ArrayList<>();


    /* *** Getters & Setters *** */
    public Recipe(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String[] getIngredients() {
        return ingredients;
    }

    public void setIngredients(String[] ingredients) {
        this.ingredients = ingredients;
    }

    public String getSubmitter() {
        return submitter;
    }

    public void setSubmitter(String submitter) {
        this.submitter = submitter;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public int getServings() {
        int serving = Integer.parseInt(this.servings);
        return serving;
    }

    public void setServings(String servings) {
        this.servings = servings;
    }

    public int getCalories() {
        String[] newCal = this.calories.split(" ");
        int cal = Integer.parseInt(newCal[0]);
        return cal;
    }

    public void setCalories(String calories) {
        this.calories = calories;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Float getRating() {
        float rate = Float.parseFloat(this.rating);
        return rate;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public ArrayList<String> getDirections() {
        return directions;
    }

    public String getPicLink() {
        return picLink;
    }

    public void setPicLink(String picLink) {
        this.picLink = picLink;
    }


}
