package database;

import recipeclasses.CookTime;
import recipeclasses.Ingredients;
import recipeclasses.Recipe;
import recipeclasses.Review;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DBHandler {

    // JDBC driver name and database URL
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://35.198.191.151:3306/p2?useSSL=false";


    //  Database credentials
    static final String USER = "root";
    static final String PASS = "admin";

    static Connection conn = null;
    static Statement stmt = null;
    static ResultSet rs = null;

    static public void createCon(){

        //Register JDBC driver
        System.out.println("Registering JDBC drivers");
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        //Open a connection
        System.out.println("Connecting to database...");
        try {
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    //Gets information to the recipe class from the database
    static public Recipe getRecipe(int ID) {
        System.out.println("Creating statement...");
        Recipe recipe = new Recipe();

        try {
            stmt = conn.createStatement();
            String sql = "SELECT title, submitter, picture_link, link, description, servings, calories, rating FROM recipe WHERE recipe_id=" + ID;
            rs = stmt.executeQuery(sql);
            //Recipe recipe = new Recipe();

            //Extract data from result set
            while (rs.next()) {
                //Retrieve by column name
                String title = rs.getString("title");
                String submitter = rs.getString("submitter");
                String pictureLink = rs.getString("picture_link");
                String websiteLink = rs.getString("link");
                String description = rs.getString("description");
                int servings = rs.getInt("servings");
                int calories = rs.getInt("calories");
                double rating = rs.getInt("rating");

                //Initializing fields in the recipe class
                recipe.setTitle(title);
                recipe.setSubmitterName(submitter);
                recipe.setPictureLink(pictureLink);
                recipe.setWebsiteLink(websiteLink);
                recipe.setDescription(description);
                recipe.setServings(servings);
                recipe.setCalories(calories);
                recipe.setRating(rating);
            }

            //   System.out.println(recipe.getTitle());

        } catch(SQLException e){
            e.printStackTrace();
        }

        return recipe;
    }

    //Gets information to the cooktime class from the database
    static public CookTime getTime(int ID) {
        System.out.println("Creating statement...");
        CookTime cookTime = new CookTime();

        try {
            stmt = conn.createStatement();
            String sql = "SELECT prep_time, cook_time, ready_in FROM time WHERE recipe_id=" + ID;
            rs = stmt.executeQuery(sql);

            //Extract data from result set
            while (rs.next()) {
                //Retrieve by column name
                String prep_Time = rs.getString("prep_time");
                String cook_Time = rs.getString("cook_time");
                String ready_In = rs.getString("ready_in");

                //Initializing fields in CookTime class
                cookTime.setPrepTime(prep_Time);
                cookTime.setCookTime(cook_Time);
                cookTime.setReadyIn(ready_In);
            }

            System.out.println(cookTime.getCookTime());

        } catch(SQLException e){
            e.printStackTrace();
        }

        return cookTime;
    }

    //Gets information to the recipe class from the database
    static public Recipe getCat(int ID) {
        System.out.println("Creating statement...");
        Recipe recipe = new Recipe();

        try {
            stmt = conn.createStatement();
            String sql = "SELECT category_name FROM categories WHERE recipe_id=" + ID;
            rs = stmt.executeQuery(sql);

            List<String> listOfCategoryNames = new ArrayList<>();

            //Extract data from result set
            while (rs.next()) {
                //Retrieve by column name
                String categoryName = rs.getString("category_name");

                //Adds all the elements to a new list - that later can be initialized in Recipe class
                listOfCategoryNames.add(categoryName);
            }

            //Initialize the field categories in Recipe class
            recipe.setCategories(listOfCategoryNames);

        } catch(SQLException e){
            e.printStackTrace();
        }

        return recipe;
    }

    //Gets information to the recipe class from the database
    static public Recipe getIngr(int ID) {
       System.out.println("Creating statement...");
        Recipe recipe = new Recipe();

        try {
            stmt = conn.createStatement();
            String sql = "SELECT amount, unit, other_unit, ingr_name FROM ingredients_formatted WHERE recipe_id=" + ID;
            rs = stmt.executeQuery(sql);

            List<Ingredients> ingredientsList = new ArrayList<>();

            //Extract data from result set
            while (rs.next()) {
                //Retrieve by column name
                double amount = rs.getDouble("amount");
                String unit = rs.getString("unit");
                String other_unit = rs.getString("other_unit");
                String ingr_name = rs.getString("ingr_name");

                //Initializing fields in CookTime class
                Ingredients ingredients = new Ingredients();
                ingredients.setAmount(amount);
                ingredients.setUnit(unit);
                ingredients.setInParentheses(other_unit);
                ingredients.setName(ingr_name);
                ingredientsList.add(ingredients);
            }

            recipe.setIngredients(ingredientsList);

        } catch(SQLException e){
            e.printStackTrace();
        }

        return recipe;
    }

    //Gets information to the recipe class from the database
    static public Recipe getDir(int ID) {
        System.out.println("Creating statement...");
        Recipe recipe = new Recipe();

        try {
            stmt = conn.createStatement();
            String sql = "SELECT directions FROM directions WHERE recipe_id=" + ID;
            rs = stmt.executeQuery(sql);


            //Adds all the elements to a new list - that later can be initialized in Recipe class
            List<String> listOfDirections = new ArrayList<>();

            //Extract data from result set
            while (rs.next()) {
                //Retrieve by column name
                String recipeDir = rs.getString("directions");

                //Adds all the elements to a new list - that later can be initialized in Recipe class
                listOfDirections.add(recipeDir);
            }

            //Initialize the field directions in Recipe class
            recipe.setDirections(listOfDirections);

        } catch(SQLException e){
            e.printStackTrace();
        }

        return recipe;
    }

    static public Recipe getRev(int ID) {
        System.out.println("Creating statement...");
        Recipe recipe = new Recipe();

        try {
            stmt = conn.createStatement();
            String sql = "SELECT review, submitter, submitter_id, individual_rating FROM reviews WHERE recipe_id=" + ID;
            rs = stmt.executeQuery(sql);

            List<Review> reviewList = new ArrayList<>();

            //5: Extract data from result set
            while (rs.next()) {
                //Retrieve by column name
                String reviewText = rs.getString("review");
                String submitterName = rs.getString("submitter");
                String submitterID = rs.getString("submitter_id");
                int individualRating = rs.getInt("individual_rating");

                //Initializing fields in the Review class
                Review review = new Review();
                review.setReview(reviewText);
                review.setSubmitterName(submitterName);
                review.setSubmitterID(submitterID);
                review.setRating(individualRating);
                reviewList.add(review);
            }

            recipe.setReviews(reviewList);
            
        } catch(SQLException e){
            e.printStackTrace();
        }

        return recipe;
    }

    static public void closeCon () {
        // what exception to use here
        try {
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        try {
            if (stmt != null)
                stmt.close();
        } catch (SQLException se2) {
        }// nothing we can do
        try {
            if (conn != null)
                conn.close();
        } catch (SQLException se) {
            se.printStackTrace();
        }

    }

}
