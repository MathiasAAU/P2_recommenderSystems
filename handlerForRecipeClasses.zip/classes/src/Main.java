import database.DBHandler;
import recipeclasses.Recipe;

public class Main {
    public static void main(String[] args) {
        DBHandler.createCon();


        Recipe recipe = DBHandler.getRecipe(3000);

        System.out.println(recipe.getTitle());

        DBHandler.closeCon();
    }
}
