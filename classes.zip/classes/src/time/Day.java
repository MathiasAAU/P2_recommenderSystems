package time;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Day {
    private List<Meal> meals = new ArrayList<>();


    public void addMeal(Meal m){
        meals.add(m);
    }

    public void deleteMeal(Meal m){
        meals.remove(m);
    }
}
