public class Main {

    public static void main(String[] args) {
        String ingredient = "4 1/2 (4 dd) lort memes";
        String splitIngredient[] = ingredient.split(" ");


        String parenthesisUnit = null;
        String parenthesisPreUnit = null;
        String unit = null;
        double amount = 0;
        int parenthesisAmount = 0;
        int unitLocation = 1;
        int offset = 0;

        Convert convert = new Convert();
        /* Standard units */
        String units[] = {"teaspoon", "tablespoon", "cup", "can", "clove", "pound", "ounce", "inch", "slice",
                          "leave", "package", "stalk", "quart", "pinch"};

        /* Ingredient has an amount */
        if (splitIngredient[0].contains("0") || splitIngredient[0].contains("1") || splitIngredient[0].contains("2") ||
                splitIngredient[0].contains("3") || splitIngredient[0].contains("4") || splitIngredient[0].contains("5") ||
                splitIngredient[0].contains("6") || splitIngredient[0].contains("7") || splitIngredient[0].contains("8") ||
                splitIngredient[0].contains("9")) {

            // If amount = fraction its made into a double
            if (splitIngredient[0].contains("/")) {
                String[] fraction = splitIngredient[0].split("/");
                amount = Double.parseDouble(fraction[0]) / Double.parseDouble(fraction[1]);
            } else {
                amount = Integer.parseInt(splitIngredient[0]);
            }
            // In the situation of eg. "3 1/3"
            if (splitIngredient[1].contains("/")) {
                String[] subFraction = splitIngredient[1].split("/");
                amount += Double.parseDouble(subFraction[0]) / Double.parseDouble(subFraction[1]);
                offset++; //offset is to move one step further in the array to accommodate this
                unitLocation += offset;
            }

            /* Units in parenthesis */
            if (splitIngredient.length > 3 + offset && (splitIngredient[1 + offset].contains("(") &&
                    splitIngredient[2 + offset].contains(")") || splitIngredient[3 + offset].contains(")"))) {
                String parenthesisArray[] = ingredient.split("[(\\)]");
                String parenthesis[] = parenthesisArray[1].split(" ");

                double doubleAmount = Double.parseDouble(parenthesis[0]);
                if (parenthesis.length == 2) {
                    parenthesisUnit = parenthesis[1];
                } else {
                    parenthesisPreUnit = parenthesis[1];
                    parenthesisUnit = parenthesis[parenthesis.length - 1];
                }

                /* Units get converted */
                if (parenthesisPreUnit.contains("fluid") && parenthesisUnit.contains("ounce")) {
                    parenthesisAmount = convert.fluidounceToLiter(doubleAmount);
                    parenthesisUnit = "milliliters";
                } else if (parenthesisUnit.contains("ounce")) {
                    parenthesisAmount = convert.ounceToGram(doubleAmount);
                    parenthesisUnit = "gram";
                } else if (parenthesisUnit.contains("pound")) {
                    parenthesisAmount = convert.poundToGram(doubleAmount);
                    parenthesisUnit = "gram";
                } else if (parenthesisUnit.contains("inch")) {
                    parenthesisAmount = convert.inchToCm(doubleAmount);
                    parenthesisUnit = "cm";
                } else if(parenthesisUnit.contains("milliliter")){
                    parenthesisAmount = (int) doubleAmount;
                    parenthesisUnit = "milliliter";
                } else if(parenthesisUnit.contains("liter")){
                    parenthesisAmount = (int) doubleAmount;
                    parenthesisUnit = "liter";
                }
                else{
                    parenthesisAmount = 0;
                    parenthesisUnit = null;
                }

                if (splitIngredient[2 + offset].contains(")")) {
                    unitLocation = 3 + offset;
                }
                if (splitIngredient[3 + offset].contains(")")) {
                    unitLocation = 4 + offset;
                }
                //System.out.println("Amount: " + parenthesisAmount + " Unit: " + parenthesisUnit);
            }

            /* Normal unit */
            for(int i = 0; i < units.length; i++){
                if(splitIngredient[unitLocation].contains(units[i])){
                    if(units[i].equals("ounce")){
                        amount = convert.ounceToGram(amount);
                        unit = "gram";
                        break;
                    } else if(units[i].equals("pound")){
                        amount = convert.poundToGram(amount);
                        unit = "gram";
                        break;
                    } else if(units[i].equals("inch")){
                        amount = convert.inchToCm(amount);
                        unit = "cm";
                        break;
                    } else if(units[i].equals("quart")){
                        amount = convert.quartToLiter(amount);
                        unit = "liter";
                        break;
                    } else {
                        unit = units[i];
                        break;
                    }
                }
            }
            if ((parenthesisUnit == null || parenthesisAmount == 0) && (amount != 0 && unit != null)){
                System.out.println("Amount: " + amount + " Unit: " + unit);
            }
            else if(parenthesisUnit != null || parenthesisAmount != 0) {
                System.out.println("Amount: " + amount + " (" + parenthesisAmount + " " + parenthesisUnit + ") Unit: " + unit);
            }
        }

    }

}