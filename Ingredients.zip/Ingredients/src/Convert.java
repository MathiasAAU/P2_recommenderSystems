public class Convert {
    private double gramPerOunce = 28.3495231;
    private double gramPerPound = 453.59237;
    private double cmPerInch = 2.54;
    private double quarterPerLiter = 0.946352946;
    private double fluidouncePerMilliliter = 29.5735296;

    public int ounceToGram(double amount){
        return (int) Math.round(amount * this.gramPerOunce);
    }

    public int poundToGram(double amount){
        return (int) Math.round(amount * this.gramPerPound);
    }

    public int inchToCm(double amount){
        return (int) Math.round(amount * this.cmPerInch);
    }

    public int quartToLiter(double amount){
        return (int) Math.round(amount * this.quarterPerLiter);
    }

    public int fluidounceToLiter(double amount){
        return (int) Math.round(amount * this.fluidouncePerMilliliter);
    }



}
